import React, { useState, useMemo, useEffect } from 'react';

// ==============================================================================
// 1. ĐỊNH NGHĨA KIỂU DỮ LIỆU (TYPESCRIPT INTERFACES)
// ==============================================================================

interface SanPham {
  id: number;
  danhMuc: string;
  ten: string;
  gia: number;
  anh: string;
}

interface ThongTinKhach {
  hoTen: string;
  sdt: string;
  hinhThucGiao: 'tan_nha' | 'hop';
  diaChi: string;
}

interface DonHang {
  id: number;
  thoiGian: string;
  khachHang: ThongTinKhach;
  chiTiet: Record<string, number>;
  tongTien: number;
  trangThai: 'moi' | 'hoan_thanh' | 'huy';
}

// ==============================================================================
// 2. CẤU HÌNH SHOP
// ==============================================================================
const THONG_TIN_SHOP = {
  tenShop: "Tạp Hóa Nhanh",
  sdtZaloChuShop: "0909000000",
  matKhauAdmin: "1234"
};

const DANH_SACH_SAN_PHAM: SanPham[] = [
  { id: 1, danhMuc: "Cà Phê", ten: "Cà phê sữa đá", gia: 25000, anh: "https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=80" },
  { id: 2, danhMuc: "Cà Phê", ten: "Bạc xỉu", gia: 28000, anh: "https://images.unsplash.com/photo-1582215438830-9b4eb640428d?w=400&q=80" },
  { id: 3, danhMuc: "Trà", ten: "Trà đào cam sả", gia: 35000, anh: "https://images.unsplash.com/photo-1594488516952-09c09c66cb1e?w=400&q=80" },
  { id: 4, danhMuc: "Trà", ten: "Trà vải hồng", gia: 35000, anh: "https://images.unsplash.com/photo-1621263764928-df1444c5e859?w=400&q=80" },
  { id: 5, danhMuc: "Đồ Ăn", ten: "Bánh mì thập cẩm", gia: 20000, anh: "https://images.unsplash.com/photo-1603569283847-aa295f0d016a?w=400&q=80" },
  { id: 6, danhMuc: "Đồ Ăn", ten: "Cơm sườn bì chả", gia: 45000, anh: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&q=80" },
];

// ==============================================================================
// 3. LOGIC APP (REACT TYPESCRIPT)
// ==============================================================================

const App: React.FC = () => {
  // State có định nghĩa kiểu
  const [gioHang, setGioHang] = useState<Record<string, number>>({});
  const [hienGioHang, setHienGioHang] = useState<boolean>(false);
  const [danhMucDangChon, setDanhMucDangChon] = useState<string>("Tất cả");
  const [tuKhoaTimKiem, setTuKhoaTimKiem] = useState<string>("");
  const [thongTinKhach, setThongTinKhach] = useState<ThongTinKhach>({ 
    hoTen: '', sdt: '', hinhThucGiao: 'tan_nha', diaChi: '' 
  });
  const [daChotDon, setDaChotDon] = useState<boolean>(false);

  // Admin state
  const [viewAdmin, setViewAdmin] = useState<boolean>(false);
  const [nhapMatKhau, setNhapMatKhau] = useState<string>("");
  const [daDangNhap, setDaDangNhap] = useState<boolean>(false);
  const [danhSachDonHang, setDanhSachDonHang] = useState<DonHang[]>([]);

  // --- FIX LỖI GIAO DIỆN (UPDATE MỚI NHẤT) ---
  useEffect(() => {
    // Cách 1: Thử tải Tailwind Script (V3)
    const scriptId = 'tailwind-cdn';
    if (!document.getElementById(scriptId)) {
      const script = document.createElement('script');
      script.id = scriptId;
      script.src = 'https://cdn.tailwindcss.com';
      document.head.appendChild(script);
    }

    // Cách 2: Tải thêm CSS tĩnh (V2) làm dự phòng nếu Script bị chặn
    const linkId = 'tailwind-css-link';
    if (!document.getElementById(linkId)) {
      const link = document.createElement('link');
      link.id = linkId;
      link.rel = 'stylesheet';
      link.href = 'https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css';
      document.head.appendChild(link);
    }
  }, []);

  // Load dữ liệu cũ
  useEffect(() => {
    const dataCu = localStorage.getItem('danhSachDonHang');
    if (dataCu) {
      try { 
        setDanhSachDonHang(JSON.parse(dataCu) as DonHang[]); 
      } catch (e) {
        console.error("Lỗi đọc dữ liệu:", e);
      }
    }
  }, []);

  // Lưu dữ liệu mới
  useEffect(() => {
    localStorage.setItem('danhSachDonHang', JSON.stringify(danhSachDonHang));
  }, [danhSachDonHang]);

  // Logic lọc sản phẩm
  const danhSachDanhMuc = useMemo(() => ["Tất cả", ...Array.from(new Set(DANH_SACH_SAN_PHAM.map(sp => sp.danhMuc)))], []);
  
  const sanPhamHienThi = useMemo(() => {
    return DANH_SACH_SAN_PHAM.filter(sp => {
      const matchDanhMuc = danhMucDangChon === "Tất cả" || sp.danhMuc === danhMucDangChon;
      const matchTuKhoa = sp.ten.toLowerCase().includes(tuKhoaTimKiem.toLowerCase());
      return matchDanhMuc && matchTuKhoa;
    });
  }, [danhMucDangChon, tuKhoaTimKiem]);

  const capNhatGioHang = (id: number, delta: number) => {
    setGioHang(prev => {
      const idStr = id.toString();
      const moi = (prev[idStr] || 0) + delta;
      if (moi <= 0) { 
        const tmp = { ...prev }; 
        delete tmp[idStr]; 
        return tmp; 
      }
      return { ...prev, [idStr]: moi };
    });
  };

  const tongTien = Object.keys(gioHang).reduce((total, id) => {
    const sp = DANH_SACH_SAN_PHAM.find(p => p.id === parseInt(id));
    return total + (sp ? sp.gia * gioHang[id] : 0);
  }, 0);
  const tongSoLuong = Object.values(gioHang).reduce((a, b) => a + b, 0);

  const xuLyDatHang = (e: React.FormEvent) => {
    e.preventDefault();
    if (!thongTinKhach.hoTen || !thongTinKhach.sdt) return alert("Vui lòng điền tên và số điện thoại!");
    if (thongTinKhach.hinhThucGiao === 'tan_nha' && !thongTinKhach.diaChi) return alert("Vui lòng nhập địa chỉ!");

    const donHangMoi: DonHang = {
      id: Date.now(),
      thoiGian: new Date().toLocaleString('vi-VN'),
      khachHang: thongTinKhach,
      chiTiet: gioHang,
      tongTien: tongTien,
      trangThai: 'moi'
    };

    setDanhSachDonHang(prev => [donHangMoi, ...prev]);

    let noiDungZalo = `🛒 ĐƠN #${donHangMoi.id}\n`;
    Object.keys(gioHang).forEach(id => {
      const sp = DANH_SACH_SAN_PHAM.find(p => p.id === parseInt(id));
      if (sp) noiDungZalo += `+ ${sp.ten} (x${gioHang[id]})\n`;
    });
    noiDungZalo += `💰 TỔNG: ${tongTien.toLocaleString('vi-VN')}đ\n`;
    noiDungZalo += `📱 ${thongTinKhach.hoTen} - ${thongTinKhach.sdt}\n`;
    noiDungZalo += thongTinKhach.hinhThucGiao === 'tan_nha' ? `🏠 ${thongTinKhach.diaChi}` : `🏢 Tại phòng họp`;

    navigator.clipboard.writeText(noiDungZalo).then(() => {
        setDaChotDon(true);
        if (confirm("Đã lưu đơn! Nhấn OK để mở Zalo gửi tin nhắn cho Shop.")) {
            window.open(`https://zalo.me/${THONG_TIN_SHOP.sdtZaloChuShop}`, '_blank');
        }
    });
  };

  const muaTiep = () => {
    setGioHang({}); setDaChotDon(false); setHienGioHang(false);
    setThongTinKhach({ hoTen: '', sdt: '', hinhThucGiao: 'tan_nha', diaChi: '' });
  };

  const dangNhapAdmin = () => {
    if (nhapMatKhau === THONG_TIN_SHOP.matKhauAdmin) setDaDangNhap(true); else alert("Sai mật khẩu!");
  };

  const doiTrangThaiDon = (id: number, trangThaiMoi: 'moi' | 'hoan_thanh' | 'huy') => {
    setDanhSachDonHang(prev => prev.map(don => don.id === id ? { ...don, trangThai: trangThaiMoi } : don));
  };

  const xoaDonHang = (id: number) => {
    if(confirm("Xóa đơn này?")) setDanhSachDonHang(prev => prev.filter(don => don.id !== id));
  };

  // --- GIAO DIỆN ADMIN ---
  if (viewAdmin) {
    return (
      <div className="min-h-screen bg-gray-100 p-4 font-sans text-gray-800">
        <div className="max-w-4xl mx-auto bg-white min-h-[90vh] rounded-xl shadow-xl overflow-hidden flex flex-col">
          <div className="bg-slate-800 text-white p-4 flex justify-between items-center shadow-md" style={{backgroundColor: '#1e293b', color: 'white'}}>
            <h1 className="font-bold text-xl">⚙️ Quản Lý Đơn Hàng</h1>
            <button onClick={() => setViewAdmin(false)} className="bg-slate-600 px-4 py-2 rounded hover:bg-slate-500 text-sm font-medium transition" style={{backgroundColor: '#475569'}}>Quay về App</button>
          </div>
          {!daDangNhap ? (
            <div className="flex-1 flex flex-col items-center justify-center p-8 space-y-4">
              <p className="text-gray-600 font-medium">Nhập mật khẩu quản trị (Mặc định: 1234)</p>
              <input 
                type="password" 
                className="w-full max-w-xs p-3 border-2 border-gray-200 rounded-lg text-center text-2xl focus:border-blue-500 focus:outline-none transition" 
                value={nhapMatKhau} 
                onChange={(e) => setNhapMatKhau(e.target.value)} 
                placeholder="****" 
              />
              <button onClick={dangNhapAdmin} className="w-full max-w-xs bg-blue-600 text-white p-3 rounded-lg font-bold hover:bg-blue-700 transition shadow-lg" style={{backgroundColor: '#2563eb', color: 'white'}}>Đăng nhập</button>
            </div>
          ) : (
            <div className="flex-1 overflow-auto bg-gray-50">
              <div className="grid grid-cols-3 gap-4 p-4 bg-white border-b text-center shadow-sm">
                <div className="bg-blue-50 p-3 rounded-xl border border-blue-100">
                  <div className="text-xs text-blue-500 uppercase font-bold tracking-wider" style={{color: '#2563eb'}}>Tổng đơn</div>
                  <div className="font-bold text-2xl text-blue-700">{danhSachDonHang.length}</div>
                </div>
                <div className="bg-green-50 p-3 rounded-xl border border-green-100">
                  <div className="text-xs text-green-500 uppercase font-bold tracking-wider" style={{color: '#16a34a'}}>Doanh thu</div>
                  <div className="font-bold text-2xl text-green-700">{danhSachDonHang.reduce((a,b) => a + (b.trangThai !== 'huy' ? b.tongTien : 0), 0).toLocaleString()}đ</div>
                </div>
                <div className="bg-orange-50 p-3 rounded-xl border border-orange-100">
                  <div className="text-xs text-orange-500 uppercase font-bold tracking-wider" style={{color: '#ea580c'}}>Đơn mới</div>
                  <div className="font-bold text-2xl text-orange-700">{danhSachDonHang.filter(d => d.trangThai === 'moi').length}</div>
                </div>
              </div>
              <div className="p-4 space-y-4">
                {danhSachDonHang.map(don => (
                  <div key={don.id} className={`p-5 rounded-xl border transition shadow-sm hover:shadow-md bg-white ${don.trangThai === 'moi' ? 'border-blue-300 ring-2 ring-blue-100' : 'border-gray-200'}`}>
                    <div className="flex justify-between mb-3 items-start">
                      <div>
                        <span className="text-xs font-mono bg-gray-100 px-2 py-1 rounded text-gray-500">#{don.id}</span>
                        <div className="font-bold text-lg mt-1">{don.khachHang.hoTen}</div>
                        <div className="text-sm text-gray-500 flex items-center gap-1">📞 {don.khachHang.sdt}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-xl text-blue-600" style={{color: '#2563eb'}}>{don.tongTien.toLocaleString()}đ</div>
                        <div className="text-xs text-gray-400 mt-1">{don.thoiGian}</div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-700 mb-4 border border-gray-100">
                       {Object.keys(don.chiTiet).map(id => {
                         const sp = DANH_SACH_SAN_PHAM.find(p => p.id === parseInt(id));
                         return sp ? (
                          <div key={id} className="flex justify-between py-1 border-b border-gray-200 border-dashed last:border-0">
                            <span>• {sp.ten}</span>
                            <span className="font-bold">x{don.chiTiet[id]}</span>
                          </div>
                         ) : null;
                       })}
                    </div>

                    <div className="flex justify-between items-center pt-2 border-t border-gray-100">
                       <div className="flex gap-2">
                          {don.trangThai === 'moi' && <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1" style={{backgroundColor: '#dbeafe', color: '#1d4ed8'}}>🔹 Mới</span>}
                          {don.trangThai === 'hoan_thanh' && <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1" style={{backgroundColor: '#dcfce7', color: '#15803d'}}>✅ Hoàn thành</span>}
                          {don.trangThai === 'huy' && <span className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1" style={{backgroundColor: '#fee2e2', color: '#b91c1c'}}>❌ Đã hủy</span>}
                       </div>
                       <div className="flex gap-2">
                          {don.trangThai !== 'hoan_thanh' && (
                            <button onClick={() => doiTrangThaiDon(don.id, 'hoan_thanh')} className="px-4 py-2 bg-green-500 text-white rounded-lg text-sm font-bold hover:bg-green-600 transition shadow-sm" style={{backgroundColor: '#22c55e', color: 'white'}}>
                              Xong
                            </button>
                          )}
                          <button onClick={() => xoaDonHang(don.id)} className="px-4 py-2 bg-gray-100 text-red-500 rounded-lg text-sm font-bold hover:bg-red-50 transition" style={{color: '#ef4444'}}>
                            Xóa
                          </button>
                       </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // --- MÀN HÌNH CHỐT ĐƠN ---
  if (daChotDon) {
    return (
      <div className="min-h-screen bg-green-50 flex items-center justify-center p-4 font-sans">
        <div className="bg-white p-8 rounded-2xl shadow-xl max-w-sm w-full text-center border-4 border-green-100">
          <div className="text-7xl mb-6">✅</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Đã tạo đơn hàng!</h2>
          <p className="text-gray-600 mb-8">Nội dung đơn đã được sao chép. Bạn hãy bấm OK để mở Zalo và gửi cho Shop nhé.</p>
          <button 
            onClick={muaTiep} 
            className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transition shadow-lg"
            style={{backgroundColor: '#2563eb', color: 'white'}}
          >
            Tạo đơn mới
          </button>
        </div>
      </div>
    );
  }

  // --- MÀN HÌNH KHÁCH HÀNG ---
  return (
    <div className="min-h-screen bg-gray-50 pb-32 font-sans relative text-gray-800">
      <button onClick={() => setViewAdmin(true)} className="absolute top-3 right-3 p-2 bg-white/10 hover:bg-white/20 rounded-full z-50 text-white text-xl backdrop-blur-sm transition">⚙️</button>

      {/* HEADER: Thêm style cứng để đảm bảo có màu xanh */}
      <header className="bg-gradient-to-r from-blue-600 to-blue-500 text-white pt-6 pb-4 sticky top-0 z-10 shadow-lg" style={{background: 'linear-gradient(to right, #2563eb, #3b82f6)', color: 'white'}}>
        <div className="px-4 mb-4 flex justify-between items-center max-w-2xl mx-auto">
          <div className="flex items-center gap-3">
            <span className="text-3xl bg-white/20 p-2 rounded-xl">🏪</span>
            <div>
              <h1 className="text-xl font-bold leading-tight">{THONG_TIN_SHOP.tenShop}</h1>
              <p className="text-xs text-blue-100 opacity-90">Đặt món nhanh - Giao tận nơi</p>
            </div>
          </div>
          <div className="relative cursor-pointer group" onClick={() => tongSoLuong > 0 && setHienGioHang(true)}>
            <div className="bg-white/20 p-2 rounded-xl group-hover:bg-white/30 transition">
              <span className="text-2xl">🛒</span>
            </div>
            {tongSoLuong > 0 && (
              <span className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs w-6 h-6 flex items-center justify-center rounded-full font-bold border-2 border-blue-600 shadow-sm animate-bounce" style={{backgroundColor: '#f97316', color: 'white'}}>
                {tongSoLuong}
              </span>
            )}
          </div>
        </div>
        
        <div className="px-4 pb-2 max-w-2xl mx-auto space-y-3">
          <div className="relative">
            <span className="absolute left-3 top-3 text-blue-200">🔍</span>
            <input 
              type="text" 
              placeholder="Bạn muốn tìm món gì..." 
              className="w-full bg-blue-800/30 text-white placeholder-blue-200 rounded-xl pl-10 pr-4 py-3 text-sm outline-none focus:ring-2 focus:ring-white/50 transition border border-blue-400/30" 
              style={{backgroundColor: 'rgba(30, 64, 175, 0.3)', color: 'white'}}
              value={tuKhoaTimKiem} 
              onChange={(e) => setTuKhoaTimKiem(e.target.value)} 
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 pt-1" style={{scrollbarWidth: 'none'}}>
            {danhSachDanhMuc.map(dm => (
              <button 
                key={dm} 
                onClick={() => setDanhMucDangChon(dm)} 
                className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition shadow-sm ${danhMucDangChon === dm ? 'bg-white text-blue-600 scale-105' : 'bg-blue-800/30 text-blue-100 hover:bg-blue-700/50'}`}
                style={danhMucDangChon === dm ? {backgroundColor: 'white', color: '#2563eb'} : {backgroundColor: 'rgba(30, 64, 175, 0.3)', color: '#dbeafe'}}
              >
                {dm}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto p-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
        {sanPhamHienThi.map(sp => (
          <div key={sp.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden flex h-32 hover:shadow-md transition">
            <div className="w-32 h-full relative">
              <img src={sp.anh} className="w-full h-full object-cover" alt=""/>
              {gioHang[sp.id] > 0 && (
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <span className="text-white font-bold text-lg drop-shadow-md">x{gioHang[sp.id]}</span>
                </div>
              )}
            </div>
            <div className="p-3 flex flex-col justify-between flex-1">
              <div>
                <div className="text-[10px] font-bold text-blue-500 uppercase tracking-wide bg-blue-50 w-fit px-2 py-0.5 rounded-full mb-1" style={{color: '#3b82f6', backgroundColor: '#eff6ff'}}>{sp.danhMuc}</div>
                <h3 className="font-bold text-gray-800 text-base line-clamp-2 leading-tight">{sp.ten}</h3>
              </div>
              <div className="flex justify-between items-end">
                <div className="text-blue-600 font-extrabold text-lg" style={{color: '#2563eb'}}>{sp.gia.toLocaleString('vi-VN')}đ</div>
                {gioHang[sp.id] ? (
                  <div className="flex items-center bg-gray-100 rounded-lg shadow-inner">
                    <button onClick={() => capNhatGioHang(sp.id, -1)} className="w-8 h-8 flex items-center justify-center text-red-500 font-bold hover:bg-gray-200 rounded-l-lg transition" style={{color: '#ef4444'}}>-</button>
                    <span className="text-sm font-bold px-2 min-w-[20px] text-center">{gioHang[sp.id]}</span>
                    <button onClick={() => capNhatGioHang(sp.id, 1)} className="w-8 h-8 flex items-center justify-center text-green-600 font-bold hover:bg-gray-200 rounded-r-lg transition" style={{color: '#22c55e'}}>+</button>
                  </div>
                ) : (
                  <button 
                    onClick={() => capNhatGioHang(sp.id, 1)} 
                    className="bg-blue-50 text-blue-600 px-4 py-2 rounded-xl text-xs font-bold hover:bg-blue-600 hover:text-white transition active:scale-95"
                    style={{backgroundColor: '#eff6ff', color: '#2563eb'}}
                  >
                    Thêm +
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </main>

      {!hienGioHang && tongSoLuong > 0 && (
        <div className="fixed bottom-6 left-4 right-4 max-w-2xl mx-auto z-20">
          <button 
            onClick={() => setHienGioHang(true)} 
            className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 rounded-2xl shadow-xl shadow-blue-600/30 flex justify-between items-center hover:scale-[1.02] transition active:scale-95"
            style={{background: 'linear-gradient(to right, #2563eb, #1d4ed8)', color: 'white'}}
          >
            <div className="flex items-center gap-3">
              <div className="bg-white/20 p-2 rounded-lg">🛒</div>
              <div className="flex flex-col items-start">
                <span className="font-bold text-sm">{tongSoLuong} món đang chọn</span>
                <span className="text-[10px] opacity-80">Bấm để xem chi tiết</span>
              </div>
            </div>
            <div className="font-bold text-xl bg-white text-blue-600 px-3 py-1 rounded-lg shadow-sm" style={{color: '#2563eb', backgroundColor: 'white'}}>
              {tongTien.toLocaleString('vi-VN')}đ
            </div>
          </button>
        </div>
      )}

      {hienGioHang && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-lg h-[90vh] sm:h-auto sm:max-h-[85vh] sm:rounded-3xl flex flex-col shadow-2xl overflow-hidden">
            <div className="p-4 border-b flex justify-between items-center bg-gray-50">
              <h2 className="font-bold text-lg text-gray-800 flex items-center gap-2">🛒 Xác nhận đơn hàng</h2>
              <button onClick={() => setHienGioHang(false)} className="p-2 bg-gray-200 hover:bg-gray-300 rounded-full text-gray-600 transition">✕</button>
            </div>
            <div className="overflow-y-auto flex-1 p-5 space-y-6">
               <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                 <div className="bg-blue-50/50 p-3 text-xs font-bold text-blue-600 uppercase tracking-wider border-b border-blue-50" style={{color: '#2563eb', backgroundColor: '#eff6ff'}}>Món đã chọn</div>
                 <div className="p-3 space-y-3">
                    {Object.keys(gioHang).map(id => {
                      const sp = DANH_SACH_SAN_PHAM.find(p => p.id === parseInt(id));
                      return sp ? (
                        <div key={id} className="flex justify-between items-center text-sm">
                          <div>
                            <span className="font-medium text-gray-800">{sp.ten}</span>
                            <div className="text-xs text-gray-500">{sp.gia.toLocaleString()}đ x {gioHang[id]}</div>
                          </div>
                          <span className="font-bold text-gray-800">{(sp.gia*gioHang[id]).toLocaleString()}đ</span>
                        </div>
                      ) : null
                    })}
                 </div>
                 <div className="bg-gray-50 p-4 flex justify-between items-center border-t border-gray-100">
                    <span className="text-gray-600 font-medium">Tổng cộng</span>
                    <span className="text-xl font-bold text-blue-600" style={{color: '#2563eb'}}>{tongTien.toLocaleString()}đ</span>
                 </div>
               </div>
               
               <form id="frmOrder" onSubmit={xuLyDatHang} className="space-y-4">
                 <div>
                    <h3 className="font-bold text-sm text-gray-800 mb-3 flex items-center gap-2">📝 Thông tin giao hàng</h3>
                    <div className="space-y-3">
                      <div className="relative group">
                        <span className="absolute left-3 top-3.5 grayscale group-focus-within:grayscale-0 transition">👤</span>
                        <input 
                          required 
                          type="text" 
                          placeholder="Tên người nhận" 
                          className="w-full pl-10 p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm outline-none focus:bg-white focus:ring-2 focus:ring-blue-500 transition" 
                          value={thongTinKhach.hoTen} 
                          onChange={(e) => setThongTinKhach({...thongTinKhach, hoTen: e.target.value})} 
                        />
                      </div>
                      <div className="relative group">
                        <span className="absolute left-3 top-3.5 grayscale group-focus-within:grayscale-0 transition">📞</span>
                        <input 
                          required 
                          type="tel" 
                          placeholder="Số điện thoại" 
                          className="w-full pl-10 p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm outline-none focus:bg-white focus:ring-2 focus:ring-blue-500 transition" 
                          value={thongTinKhach.sdt} 
                          onChange={(e) => setThongTinKhach({...thongTinKhach, sdt: e.target.value})} 
                        />
                      </div>
                    </div>
                 </div>

                 <div className="grid grid-cols-2 gap-3">
                   <button 
                    type="button" 
                    onClick={() => setThongTinKhach({...thongTinKhach, hinhThucGiao:'tan_nha'})} 
                    className={`p-3 border-2 rounded-xl text-sm font-bold flex flex-col items-center gap-2 transition ${thongTinKhach.hinhThucGiao === 'tan_nha' ? 'bg-blue-50 border-blue-500 text-blue-700' : 'border-gray-100 text-gray-500 hover:bg-gray-50'}`}
                    style={thongTinKhach.hinhThucGiao === 'tan_nha' ? {borderColor: '#3b82f6', backgroundColor: '#eff6ff', color: '#1d4ed8'} : {}}
                   >
                     <span className="text-2xl">🏠</span> Giao tận nơi
                   </button>
                   <button 
                    type="button" 
                    onClick={() => setThongTinKhach({...thongTinKhach, hinhThucGiao:'hop'})} 
                    className={`p-3 border-2 rounded-xl text-sm font-bold flex flex-col items-center gap-2 transition ${thongTinKhach.hinhThucGiao === 'hop' ? 'bg-blue-50 border-blue-500 text-blue-700' : 'border-gray-100 text-gray-500 hover:bg-gray-50'}`}
                    style={thongTinKhach.hinhThucGiao === 'hop' ? {borderColor: '#3b82f6', backgroundColor: '#eff6ff', color: '#1d4ed8'} : {}}
                   >
                     <span className="text-2xl">🏢</span> Tại phòng họp
                   </button>
                 </div>
                 
                 {thongTinKhach.hinhThucGiao === 'tan_nha' && (
                   <div className="animate-in slide-in-from-top-2 duration-200">
                     <textarea 
                       required 
                       placeholder="Nhập địa chỉ chi tiết (Số nhà, đường...)" 
                       className="w-full p-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm h-24 outline-none focus:bg-white focus:ring-2 focus:ring-blue-500 transition resize-none" 
                       value={thongTinKhach.diaChi} 
                       onChange={(e) => setThongTinKhach({...thongTinKhach, diaChi: e.target.value})}
                     />
                   </div>
                 )}
               </form>
            </div>
            <div className="p-4 border-t bg-gray-50">
              <button 
                form="frmOrder" 
                type="submit" 
                className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-4 rounded-xl font-bold text-lg hover:shadow-lg transition active:scale-[0.98] flex items-center justify-center gap-3"
                style={{background: 'linear-gradient(to right, #2563eb, #1d4ed8)', color: 'white'}}
              >
                <span>📤</span> Chốt đơn & Gửi Zalo
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;